#ifndef _api_H_
#define _api_H_

#include  "../header/halGPIO.h"     // private library - HAL layer

extern void tone_recoder(void);
extern void audio_player(void);    
extern void mirror_string(const char *s);

#endif





