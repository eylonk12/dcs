The script at the file performs communication between the pc and the microprocessor
the state machine of the script is 1. receive state 2. write state to MP (with optional writing of delay) and 
optionally 3. wait for input at the RX buffer from the MP.
