Ex1: in this example we send a character, and receive a string in response only if the start character was 'u'
Ex2: in this example we sends a character and ping pong the input character "pingPongNum" times before the port closes
Ex3: this example implements a chat where the PC sends a message/character and receives a response