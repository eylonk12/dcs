Ex1: send a string when receiving 'u' character
Ex2: echo received character
Ex3: echo received character/string with '\n' terminator